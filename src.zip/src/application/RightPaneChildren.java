package application;

public interface RightPaneChildren {
    public String getTypee();

}
