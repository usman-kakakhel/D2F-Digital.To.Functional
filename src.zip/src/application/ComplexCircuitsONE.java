/**
 * @author Daniyal Khalil
 * last edit: 10 May 2018
 */
package application;

public abstract class ComplexCircuitsONE extends GateInput
{


    /**
     * method input GateInputs
     * @param inputs the GateInputs
     */
  public abstract void input(GateInput... inputs);

  
}